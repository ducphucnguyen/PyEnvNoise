# -*- coding: utf-8 -*-
"""
Created on Fri Aug  6 13:44:59 2021

@author: nguy0936
"""
from .ptiread import ptiread
